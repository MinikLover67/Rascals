import{i as r}from"./index-Ro24jUzp.js";async function i(){await r("plugin:process|restart")}export{i as relaunch};
